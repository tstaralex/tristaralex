<?php
//include('dbconnected.php');
include('koneksi.php');

$jumlah = $_GET['jumlah'];
$tgl_hutang = $_GET['tgl_deadline'];
$rincian = $_GET['rincian'];
$koor = $_GET['koordinator'];


//query update
$query = mysqli_query($koneksi,"INSERT INTO `tugas` (`jumlah`, `tgl_deadline`, `rincian`, `koordinator`) VALUES ('$jumlah', '$tgl_hutang', '$rincian','$koor')");

if ($query) {
 # credirect ke page index
 header("location:tugas.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>