<?php

$host = 'root';
$nama = '';
$pass = '';
$db = '';

$koneksi = mysqli_connect($host, $nama,$pass, $db);
?>