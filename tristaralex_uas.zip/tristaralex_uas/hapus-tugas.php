<?php
//include('dbconnected.php');
include('koneksi.php');

$id = $_GET['id_tugas'];

//query update
$query = mysqli_query($koneksi,"DELETE FROM `tugas` WHERE id_tugas = '$id'");

if ($query) {
 # credirect ke page index
 header("location:tugas.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>